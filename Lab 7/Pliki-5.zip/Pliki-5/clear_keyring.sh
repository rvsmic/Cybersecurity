#!/bin/bash

function clean(){
    rm -rf *.key *.enc *.dec *.txt *.b64 *.pass *.zip *.sig *.asc
    for i in `gpg --with-colons --fingerprint | grep "^fpr" | cut -d: -f10`; do gpg --batch --yes --delete-secret-keys "$i" ; done 1> /dev/null 2> /dev/null
    for i in `gpg --with-colons --fingerprint | grep "^fpr" | cut -d: -f10`; do gpg --batch --yes --delete-keys "$i" ; done 1> /dev/null 2> /dev/null
}
